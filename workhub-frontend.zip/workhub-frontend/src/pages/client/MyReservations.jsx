import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import config from "../../config";
import "./MyReservations.css";

const MyReservations = () => {
    const [reservations, setReservations] = useState([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    useEffect(() => {
        fetchReservations();
    }, []);

    const fetchReservations = async () => {
        setLoading(true);
        try {
            const res = await fetch(`${config.API_BASE}/reservations/my`, {
                headers: {
                    Authorization: `Bearer ${localStorage.getItem("token")}`,
                },
            });

            const data = await res.json();
            setReservations(Array.isArray(data) ? data : []);
        } catch (error) {
            console.error("Erro ao carregar reservas:", error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="auth-page">
            <div className="auth-card" style={{ maxWidth: "1000px" }}>
                <div className="auth-header">
                    <h1>Minhas Reservas</h1>
                    <p>Consulta o histórico das tuas reservas</p>
                </div>

                {loading ? (
                    <p style={{ textAlign: "center", padding: "40px" }}>A carregar reservas...</p>
                ) : reservations.length === 0 ? (
                    <p style={{ textAlign: "center", padding: "40px", color: "#888" }}>
                        Ainda não tens nenhuma reserva.
                    </p>
                ) : (
                    <div className="reservations-list">
                        {reservations.map((res) => (
                            <div key={res._id} className="reservation-card">
                                <div className="reservation-info">
                                    <h3>{res.space?.tipo || "Espaço"}</h3>
                                    <p><strong>Data:</strong> {new Date(res.dataInicio).toLocaleDateString()}</p>
                                    <p><strong>Estado:</strong> 
                                        <span className={`status ${res.estado?.toLowerCase()}`}>
                                            {res.estado}
                                        </span>
                                    </p>
                                    <p><strong>Preço total:</strong> {res.precoTotal || "—"}€</p>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

export default MyReservations;