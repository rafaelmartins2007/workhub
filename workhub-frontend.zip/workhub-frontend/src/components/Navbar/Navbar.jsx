import { Link, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import "./Navbar.css";

const Navbar = () => {
    const navigate = useNavigate();
    const [user, setUser] = useState(null);

    useEffect(() => {
        const storedUser = localStorage.getItem("user");
        if (storedUser) {
            setUser(JSON.parse(storedUser));
        }
    }, []);

    const handleLogout = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        setUser(null);
        navigate("/login");
    };

    return (
        <nav className="navbar">
            <div className="navbar-container">
                {/* Logo */}
                <div className="navbar-brand">
                    <Link to="/">WorkHub Spaces</Link>
                </div>

                {/* Links */}
                <div className="navbar-links">
                    <Link to="/spaces">Catálogo de Espaços</Link>
                    {user && <Link to="/my-reservations">Minhas Reservas</Link>}
                </div>

                {/* Direita */}
                <div className="navbar-right">
                    {user ? (
                        <>
                            <span className="user-name">Olá, {user.nome}</span>
                            <button onClick={handleLogout} className="btn-logout">
                                Sair
                            </button>
                        </>
                    ) : (
                        <Link to="/login" className="btn-login">
                            Entrar
                        </Link>
                    )}
                </div>
            </div>
        </nav>
    );
};

export default Navbar;